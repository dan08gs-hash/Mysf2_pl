package com.mysf2.android.audio

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.mysf2.android.model.SoundFontMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class SoundFontManager(private val context: Context) {

    private val sf2Directory = File(context.filesDir, "soundfonts").apply {
        if (!exists()) mkdirs()
    }

    suspend fun importSoundFont(uri: Uri): Result<SoundFontMeta> = withContext(Dispatchers.IO) {
        try {
            val fileName = queryFileName(uri) ?: "instrument.sf2"
            val targetFile = File(sf2Directory, fileName)

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                }
            } ?: return@withContext Result.failure(Exception("Não foi possível acessar o arquivo SF2."))

            Result.success(
                SoundFontMeta(
                    fileName = fileName,
                    absolutePath = targetFile.absolutePath,
                    sizeBytes = targetFile.length()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun queryFileName(uri: Uri): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    name = cursor.getString(nameIndex)
                }
            }
        }
        return name ?: uri.lastPathSegment
    }
}
