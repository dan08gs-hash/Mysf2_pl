package com.mysf2.android.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BLACK_KEYS = setOf(1, 3, 6, 8, 10)

@Composable
fun VirtualKeyboard(
    startNote: Int = 48,
    totalWhiteKeys: Int = 14,
    activeNotes: Set<Int>,
    onNoteOn: (Int) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val whiteNotes = remember(startNote, totalWhiteKeys) {
        val list = mutableListOf<Int>()
        var curr = startNote
        while (list.size < totalWhiteKeys) {
            val noteInOctave = curr % 12
            if (noteInOctave !in BLACK_KEYS) {
                list.add(curr)
            }
            curr++
        }
        list
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(Color(0xFF1A1A1A))
    ) {
        val totalWidth = maxWidth
        val keyWidth = totalWidth / totalWhiteKeys

        Row(modifier = Modifier.fillMaxSize()) {
            whiteNotes.forEach { note ->
                val isPressed = activeNotes.contains(note)
                Box(
                    modifier = Modifier
                        .width(keyWidth)
                        .fillMaxHeight()
                        .background(if (isPressed) Color(0xFF64B5F6) else Color.White)
                        .border(1.dp, Color.Black)
                        .pointerInput(note) {
                            awaitEachGesture {
                                awaitFirstDown(pass = PointerEventPass.Main)
                                onNoteOn(note)
                                waitForUpOrCancellation()
                                onNoteOff(note)
                            }
                        },
                    contentAlignment = Alignment.BottomCenter
                ) {
                    if (note % 12 == 0) {
                        Text(
                            text = "C${(note / 12) - 1}",
                            fontSize = 11.sp,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }
            }
        }

        val blackKeyWidth = keyWidth * 0.65f
        val blackKeyHeight = maxHeight * 0.6f

        var currentX = 0.dp
        for (i in 0 until whiteNotes.size - 1) {
            val currentNote = whiteNotes[i]
            val nextNote = currentNote + 1
            currentX += keyWidth

            if ((nextNote % 12) in BLACK_KEYS) {
                val isPressed = activeNotes.contains(nextNote)
                val leftOffset = currentX - (blackKeyWidth / 2)

                Box(
                    modifier = Modifier
                        .offset(x = leftOffset)
                        .width(blackKeyWidth)
                        .height(blackKeyHeight)
                        .background(if (isPressed) Color(0xFFE57373) else Color.Black)
                        .border(1.dp, Color.DarkGray)
                        .pointerInput(nextNote) {
                            awaitEachGesture {
                                awaitFirstDown(pass = PointerEventPass.Main)
                                onNoteOn(nextNote)
                                waitForUpOrCancellation()
                                onNoteOff(nextNote)
                            }
                        }
                )
            }
        }
    }
}
