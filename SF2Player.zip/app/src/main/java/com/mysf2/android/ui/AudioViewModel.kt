package com.mysf2.android.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mysf2.android.audio.NativeAudioEngine
import com.mysf2.android.audio.SoundFontManager
import com.mysf2.android.midi.MidiDeviceManager
import com.mysf2.android.model.Preset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val soundFontName: String? = null,
    val presets: List<Preset> = emptyList(),
    val selectedPreset: Preset? = null,
    val masterVolume: Float = 0.8f,
    val polyphony: Int = 64,
    val midiDeviceName: String? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val activeKeys: Set<Int> = emptySet()
)

class AudioViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val soundFontManager = SoundFontManager(application)
    private val midiDeviceManager = MidiDeviceManager(application)

    init {
        NativeAudioEngine.init()
        NativeAudioEngine.start()
        NativeAudioEngine.setMasterVolume(0.8f)

        midiDeviceManager.onDeviceConnected = { name ->
            _uiState.update { it.copy(midiDeviceName = name) }
        }
        midiDeviceManager.onDeviceDisconnected = {
            _uiState.update { it.copy(midiDeviceName = null) }
        }
        midiDeviceManager.startListening()
    }

    fun loadSoundFontFromUri(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = soundFontManager.importSoundFont(uri)

            result.onSuccess { meta ->
                val loaded = NativeAudioEngine.loadSoundFont(meta.absolutePath)
                if (loaded) {
                    val presets = NativeAudioEngine.getPresets()
                    val defaultPreset = presets.firstOrNull()
                    if (defaultPreset != null) {
                        NativeAudioEngine.selectProgram(0, defaultPreset.bank, defaultPreset.program)
                    }

                    _uiState.update {
                        it.copy(
                            soundFontName = meta.fileName,
                            presets = presets,
                            selectedPreset = defaultPreset,
                            isLoading = false
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(isLoading = false, errorMessage = "Formato de SoundFont inválido ou incompatível.")
                    }
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = error.localizedMessage ?: "Erro ao abrir SoundFont.")
                }
            }
        }
    }

    fun selectPreset(preset: Preset) {
        NativeAudioEngine.selectProgram(0, preset.bank, preset.program)
        _uiState.update { it.copy(selectedPreset = preset) }
    }

    fun setMasterVolume(vol: Float) {
        NativeAudioEngine.setMasterVolume(vol)
        _uiState.update { it.copy(masterVolume = vol) }
    }

    fun noteOn(key: Int, velocity: Int = 100) {
        NativeAudioEngine.noteOn(0, key, velocity)
        _uiState.update { it.copy(activeKeys = it.activeKeys + key) }
    }

    fun noteOff(key: Int) {
        NativeAudioEngine.noteOff(0, key)
        _uiState.update { it.copy(activeKeys = it.activeKeys - key) }
    }

    override fun onCleared() {
        super.onCleared()
        midiDeviceManager.closeMidiDevice()
        NativeAudioEngine.stop()
        NativeAudioEngine.destroy()
    }
}
