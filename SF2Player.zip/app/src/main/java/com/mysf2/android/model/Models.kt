package com.mysf2.android.model

data class Preset(
    val bank: Int,
    val program: Int,
    val name: String
) {
    override fun toString(): String = "[$bank:$program] $name"
}

data class SoundFontMeta(
    val fileName: String,
    val absolutePath: String,
    val sizeBytes: Long
)
