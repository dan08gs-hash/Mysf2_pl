package com.mysf2.android.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import com.mysf2.android.audio.NativeAudioEngine

class MidiDeviceManager(context: Context) {

    private val midiManager = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private var openDevice: MidiDevice? = null
    private var outputPort: MidiOutputPort? = null

    var onDeviceConnected: ((String) -> Unit)? = null
    var onDeviceDisconnected: (() -> Unit)? = null

    private val midiReceiver = object : MidiReceiver() {
        override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
            var i = offset
            val end = offset + count
            while (i < end) {
                val status = data[i].toInt() and 0xFF
                if (status >= 0x80) {
                    val command = status and 0xF0
                    val channel = status and 0x0F

                    when (command) {
                        0x90 -> {
                            if (i + 2 < end) {
                                val key = data[i + 1].toInt() and 0x7F
                                val vel = data[i + 2].toInt() and 0x7F
                                if (vel > 0) {
                                    NativeAudioEngine.noteOn(channel, key, vel)
                                } else {
                                    NativeAudioEngine.noteOff(channel, key)
                                }
                                i += 3
                                continue
                            }
                        }
                        0x80 -> {
                            if (i + 2 < end) {
                                val key = data[i + 1].toInt() and 0x7F
                                NativeAudioEngine.noteOff(channel, key)
                                i += 3
                                continue
                            }
                        }
                    }
                }
                i++
            }
        }
    }

    fun startListening() {
        midiManager ?: return
        val devices = midiManager.devices
        if (devices.isNotEmpty()) {
            openMidiDevice(devices[0])
        }

        midiManager.registerDeviceCallback(object : MidiManager.DeviceCallback() {
            override fun onDeviceAdded(deviceInfo: MidiDeviceInfo) {
                openMidiDevice(deviceInfo)
            }

            override fun onDeviceRemoved(deviceInfo: MidiDeviceInfo) {
                closeMidiDevice()
            }
        }, Handler(Looper.getMainLooper()))
    }

    private fun openMidiDevice(deviceInfo: MidiDeviceInfo) {
        midiManager?.openDevice(deviceInfo, { device ->
            if (device != null) {
                openDevice = device
                if (deviceInfo.outputPortCount > 0) {
                    outputPort = device.openOutputPort(0)
                    outputPort?.connect(midiReceiver)
                    val devName = deviceInfo.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Dispositivo MIDI"
                    onDeviceConnected?.invoke(devName)
                }
            }
        }, Handler(Looper.getMainLooper()))
    }

    fun closeMidiDevice() {
        try {
            outputPort?.close()
            openDevice?.close()
        } catch (_: Exception) {}
        outputPort = null
        openDevice = null
        onDeviceDisconnected?.invoke()
    }
}
