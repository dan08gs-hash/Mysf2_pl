package com.mysf2.android.audio

import com.mysf2.android.model.Preset

object NativeAudioEngine {
    init {
        System.loadLibrary("sf2engine")
    }

    external fun init()
    external fun start(): Boolean
    external fun stop()
    external fun loadSoundFont(path: String): Boolean
    external fun unloadSoundFont()
    external fun noteOn(channel: Int, key: Int, velocity: Int)
    external fun noteOff(channel: Int, key: Int)
    external fun selectProgram(channel: Int, bank: Int, program: Int)
    external fun setMasterVolume(volume: Float)
    external fun setPolyphony(polyphony: Int)
    external fun allNotesOff()
    external fun getPresets(): ArrayList<Preset>
    external fun destroy()
}
