package com.mysf2.android.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mysf2.android.ui.components.VirtualKeyboard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: AudioViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val sf2Picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadSoundFontFromUri(it) }
    }

    var expandedPresetDropdown by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SF2 Player") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    uiState.midiDeviceName?.let { deviceName ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Icon(Icons.Default.Usb, contentDescription = "MIDI", tint = Color(0xFF4CAF50))
                            Spacer(Modifier.width(4.dp))
                            Text(deviceName, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    IconButton(onClick = { sf2Picker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "Carregar SF2")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Audiotrack, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = uiState.soundFontName ?: "Nenhum SoundFont carregado",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }

                        Spacer(Modifier.height(10.dp))

                        ExposedDropdownMenuBox(
                            expanded = expandedPresetDropdown,
                            onExpandedChange = { expandedPresetDropdown = !expandedPresetDropdown }
                        ) {
                            OutlinedTextField(
                                value = uiState.selectedPreset?.toString() ?: "Selecione o Instrumento",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Instrumento SF2") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPresetDropdown) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )

                            ExposedDropdownMenu(
                                expanded = expandedPresetDropdown,
                                onDismissRequest = { expandedPresetDropdown = false }
                            ) {
                                uiState.presets.forEach { preset ->
                                    DropdownMenuItem(
                                        text = { Text(preset.toString()) },
                                        onClick = {
                                            viewModel.selectPreset(preset)
                                            expandedPresetDropdown = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        Text(
                            text = "Volume Master: ${(uiState.masterVolume * 100).toInt()}%",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = uiState.masterVolume,
                            onValueChange = { viewModel.setMasterVolume(it) },
                            valueRange = 0f..1.5f
                        )
                    }
                }

                if (uiState.isLoading) {
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                uiState.errorMessage?.let { error ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = error,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Column {
                VirtualKeyboard(
                    startNote = 48,
                    totalWhiteKeys = 14,
                    activeNotes = uiState.activeKeys,
                    onNoteOn = { note -> viewModel.noteOn(note) },
                    onNoteOff = { note -> viewModel.noteOff(note) }
                )
            }
        }
    }
}
