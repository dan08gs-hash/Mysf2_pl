#include <jni.h>
#include <string>
#include "sf2_engine.h"

static SF2Engine* gEngine = nullptr;

extern "C" {

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_init(JNIEnv *env, jobject thiz) {
    if (!gEngine) {
        gEngine = new SF2Engine();
    }
}

JNIEXPORT jboolean JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_start(JNIEnv *env, jobject thiz) {
    return (gEngine && gEngine->startAudio()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_stop(JNIEnv *env, jobject thiz) {
    if (gEngine) {
        gEngine->stopAudio();
    }
}

JNIEXPORT jboolean JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_loadSoundFont(JNIEnv *env, jobject thiz, jstring path) {
    if (!gEngine) return JNI_FALSE;
    const char *nativePath = env->GetStringUTFChars(path, nullptr);
    bool success = gEngine->loadSoundFont(std::string(nativePath));
    env->ReleaseStringUTFChars(path, nativePath);
    return success ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_unloadSoundFont(JNIEnv *env, jobject thiz) {
    if (gEngine) {
        gEngine->unloadSoundFont();
    }
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_noteOn(JNIEnv *env, jobject thiz, jint channel, jint key, jint velocity) {
    if (gEngine) {
        gEngine->noteOn(channel, key, velocity);
    }
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_noteOff(JNIEnv *env, jobject thiz, jint channel, jint key) {
    if (gEngine) {
        gEngine->noteOff(channel, key);
    }
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_selectProgram(JNIEnv *env, jobject thiz, jint channel, jint bank, jint program) {
    if (gEngine) {
        gEngine->selectProgram(channel, bank, program);
    }
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_setMasterVolume(JNIEnv *env, jobject thiz, jfloat volume) {
    if (gEngine) {
        gEngine->setMasterVolume(volume);
    }
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_setPolyphony(JNIEnv *env, jobject thiz, jint polyphony) {
    if (gEngine) {
        gEngine->setPolyphony(polyphony);
    }
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_allNotesOff(JNIEnv *env, jobject thiz) {
    if (gEngine) {
        gEngine->allNotesOff();
    }
}

JNIEXPORT jobject JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_getPresets(JNIEnv *env, jobject thiz) {
    jclass arrayListClass = env->FindClass("java/util/ArrayList");
    jmethodID arrayListInit = env->GetMethodID(arrayListClass, "<init>", "()V");
    jmethodID arrayListAdd = env->GetMethodID(arrayListClass, "add", "(Ljava/lang/Object;)Z");

    jclass presetClass = env->FindClass("com/mysf2/android/model/Preset");
    jmethodID presetInit = env->GetMethodID(presetClass, "<init>", "(IILjava/lang/String;)V");

    jobject listObj = env->NewObject(arrayListClass, arrayListInit);

    if (gEngine) {
        auto presets = gEngine->getPresets();
        for (const auto& p : presets) {
            jstring nameStr = env->NewStringUTF(p.name.c_str());
            jobject pObj = env->NewObject(presetClass, presetInit, p.bank, p.program, nameStr);
            env->CallBooleanMethod(listObj, arrayListAdd, pObj);
            env->DeleteLocalRef(nameStr);
            env->DeleteLocalRef(pObj);
        }
    }

    return listObj;
}

JNIEXPORT void JNICALL
Java_com_mysf2_android_audio_NativeAudioEngine_destroy(JNIEnv *env, jobject thiz) {
    if (gEngine) {
        delete gEngine;
        gEngine = nullptr;
    }
}

}
