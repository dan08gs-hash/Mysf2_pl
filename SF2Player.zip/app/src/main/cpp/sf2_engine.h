#ifndef SF2_ENGINE_H
#define SF2_ENGINE_H

#include <oboe/Oboe.h>
#include <fluidlite.h>
#include <string>
#include <vector>
#include <mutex>

struct PresetInfo {
    int bank;
    int program;
    std::string name;
};

class SF2Engine : public oboe::AudioStreamDataCallback {
public:
    SF2Engine();
    ~SF2Engine();

    bool startAudio();
    void stopAudio();

    bool loadSoundFont(const std::string& path);
    void unloadSoundFont();

    void noteOn(int channel, int key, int velocity);
    void noteOff(int channel, int key);
    void selectProgram(int channel, int bank, int program);
    void setMasterVolume(float volume);
    void setPolyphony(int polyphony);
    void allNotesOff();

    std::vector<PresetInfo> getPresets();
    bool isLoaded() const { return mSoundFontId >= 0; }

    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream *oboeStream,
        void *audioData,
        int32_t numFrames) override;

private:
    std::shared_ptr<oboe::AudioStream> mStream;
    fluid_settings_t* mSettings{nullptr};
    fluid_synth_t* mSynth{nullptr};
    int mSoundFontId{-1};

    int32_t mSampleRate{48000};
    const int32_t mChannelCount{2};

    std::mutex mSynthMutex;
    float mMasterVolume{1.0f};
};

#endif // SF2_ENGINE_H
