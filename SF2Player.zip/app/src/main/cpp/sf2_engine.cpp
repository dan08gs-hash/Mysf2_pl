#include "sf2_engine.h"
#include <android/log.h>
#include <cstring>

#define TAG "SF2EngineNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

SF2Engine::SF2Engine() {
    mSettings = new_fluid_settings();
    fluid_settings_setnum(mSettings, "synth.sample-rate", 48000.0);
    fluid_settings_setint(mSettings, "synth.polyphony", 64);
    mSynth = new_fluid_synth(mSettings);
}

SF2Engine::~SF2Engine() {
    stopAudio();
    if (mSynth) {
        delete_fluid_synth(mSynth);
        mSynth = nullptr;
    }
    if (mSettings) {
        delete_fluid_settings(mSettings);
        mSettings = nullptr;
    }
}

bool SF2Engine::startAudio() {
    std::lock_guard<std::mutex> lock(mSynthMutex);

    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
           ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
           ->setSharingMode(oboe::SharingMode::Exclusive)
           ->setFormat(oboe::AudioFormat::Float)
           ->setChannelCount(mChannelCount)
           ->setSampleRate(mSampleRate)
           ->setDataCallback(this);

    oboe::Result result = builder.openStream(mStream);
    if (result != oboe::Result::OK) {
        LOGE("Falha ao abrir stream Oboe");
        return false;
    }

    mSampleRate = mStream->getSampleRate();
    if (mSynth) {
        fluid_synth_set_sample_rate(mSynth, (float)mSampleRate);
    }

    result = mStream->requestStart();
    if (result != oboe::Result::OK) {
        mStream->close();
        return false;
    }

    return true;
}

void SF2Engine::stopAudio() {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mStream) {
        mStream->stop();
        mStream->close();
        mStream.reset();
    }
}

bool SF2Engine::loadSoundFont(const std::string& path) {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (!mSynth) return false;

    if (mSoundFontId >= 0) {
        fluid_synth_sfunload(mSynth, mSoundFontId, 1);
        mSoundFontId = -1;
    }

    mSoundFontId = fluid_synth_sfload(mSynth, path.c_str(), 1);
    if (mSoundFontId < 0) {
        return false;
    }

    fluid_synth_program_select(mSynth, 0, mSoundFontId, 0, 0);
    return true;
}

void SF2Engine::unloadSoundFont() {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mSynth && mSoundFontId >= 0) {
        fluid_synth_sfunload(mSynth, mSoundFontId, 1);
        mSoundFontId = -1;
    }
}

void SF2Engine::noteOn(int channel, int key, int velocity) {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mSynth) {
        fluid_synth_noteon(mSynth, channel, key, velocity);
    }
}

void SF2Engine::noteOff(int channel, int key) {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mSynth) {
        fluid_synth_noteoff(mSynth, channel, key);
    }
}

void SF2Engine::selectProgram(int channel, int bank, int program) {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mSynth && mSoundFontId >= 0) {
        fluid_synth_program_select(mSynth, channel, mSoundFontId, bank, program);
    }
}

void SF2Engine::setMasterVolume(float volume) {
    mMasterVolume = volume;
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mSynth) {
        fluid_synth_set_gain(mSynth, volume);
    }
}

void SF2Engine::setPolyphony(int polyphony) {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mSynth) {
        fluid_synth_set_polyphony(mSynth, polyphony);
    }
}

void SF2Engine::allNotesOff() {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    if (mSynth) {
        fluid_synth_all_notes_off(mSynth, 0);
    }
}

std::vector<PresetInfo> SF2Engine::getPresets() {
    std::lock_guard<std::mutex> lock(mSynthMutex);
    std::vector<PresetInfo> result;
    if (!mSynth || mSoundFontId < 0) return result;

    fluid_sfont_t* sfont = fluid_synth_get_sfont_by_id(mSynth, mSoundFontId);
    if (!sfont) return result;

    fluid_preset_t preset;
    fluid_sfont_iteration_start(sfont);
    while (fluid_sfont_iteration_next(sfont, &preset)) {
        PresetInfo info;
        info.bank = fluid_preset_get_banknum(&preset);
        info.program = fluid_preset_get_num(&preset);
        const char* name = fluid_preset_get_name(&preset);
        info.name = (name != nullptr) ? std::string(name) : "Preset";
        result.push_back(info);
    }

    return result;
}

oboe::DataCallbackResult SF2Engine::onAudioReady(
    oboe::AudioStream *oboeStream,
    void *audioData,
    int32_t numFrames) {

    auto *outputBuffer = static_cast<float *>(audioData);

    std::unique_lock<std::mutex> lock(mSynthMutex, std::try_to_lock);
    if (!lock.owns_lock() || !mSynth) {
        std::memset(outputBuffer, 0, numFrames * mChannelCount * sizeof(float));
        return oboe::DataCallbackResult::Continue;
    }

    int ret = fluid_synth_write_float(
        mSynth,
        numFrames,
        outputBuffer, 0, 2,
        outputBuffer, 1, 2
    );

    if (ret != 0) {
        std::memset(outputBuffer, 0, numFrames * mChannelCount * sizeof(float));
    }

    return oboe::DataCallbackResult::Continue;
}
